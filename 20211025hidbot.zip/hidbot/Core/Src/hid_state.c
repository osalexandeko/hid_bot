#include "hid_state.h"

hid_state_t hid_state;
keyboardHID_t keyboardHID_zerrors ={0}; //used for reset
