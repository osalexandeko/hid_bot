#include "hid_mouse.h"

//the mouse hid
//mouseHID_t s_mouse_hid;